<?php

$name = $_POST['e_name'];
$id = $_POST['e_id'];
$age = $_POST['e_age'];
$qual = $_POST['e_qual'];
$des = $_POST['e_des'];

echo "<h2>The Employee named $name, has id $id<br>";
if($age > 35){
    echo "he/she is $age old, is eligible for Promotion<br>";
}else{
    echo "he/she is $age old, is not eligible for Promotion<br>";
}
echo "his/her Qualification is $qual and Designation is $des<br></h2>";
?>