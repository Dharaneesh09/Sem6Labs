<?php

$a = $_POST["inp1"];
$prime = true;

for($i=2;$i<$a/2;$i++){
    if($a%$i == 0){
        $prime = false;
        break;
    }
}
if($prime){
    echo "Recieved number $a and it's a prime number";
}else{
    echo "Recieved number $a and it's NOT a prime number";
}

?>