<?php

$num1 = $_POST["inp1"];
$num2 = $_POST["inp2"];
$g_str = $_POST["inp3"];

function powOf6($num){
    $pre = 1;
    while(true){
        if($pre==$num){
            return(true);
        }
        if($pre>$num){
            return(false);
        }
        $pre *= 6;
    }
}
if(powOf6($num1)){
    echo "Recieved first number is $num1 and it is a power of 6<br>";
}else{
    echo "Recieved first number is $num1 and it is not a power of 6<br>";
}
if($num2>$num1){
    echo "Recieved second number is $num2 and it is greater than first number<br>";
}else{
    echo "Recieved second number is $num2 and it is less than first number<br>";
}
echo "Recieved string is $g_str and when reversed it is ".strrev ($g_str)."<br>";
?>