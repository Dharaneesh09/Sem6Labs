var http = require('http');
var fs = require('fs');

var server = http.createServer(function(req, res){
    res.writeHead(200, {'Content-Type':'text/html'})
    // res.write("Node JS App");
    fs.readFile("primeCheck.html",null,function(err, data){
        if(err){
            res.writeHead(404);
            res.write("<h1>404 : File not Found</h1>");
        }else{
            res.write(data);
        }
        res.end();
    });
    
});
server.listen(8080);
console.log("Server runnning at http://localhost:8080");
