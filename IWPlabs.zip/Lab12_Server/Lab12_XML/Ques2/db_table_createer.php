<?php

$con = mysqli_connect("localhost","root","") or die("Couldn't connect to Database");

$db = mysqli_query($con,"create database railway_db");

mysqli_query($con, "use railway_db");

$train_table = mysqli_query($con,"create table trains(tid int, name varchar(30),from_sta varchar(30),to_sta varchar(30),no_seats integer(6), constraint tpk primary key(tid))") or die("Couldn't create table train");

$passenger_table = mysqli_query($con,"create table passengers(pid int, name varchar(30),addr varchar(300),tid int, no_seats int, constraint ppk primary key(pid))") or die("Couldn't create table employee");

?>