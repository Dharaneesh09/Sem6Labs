<?php 
    $con = mysqli_connect("localhost","root","","railway_db") or die("Couldn't connect to database");

    $query = "";
    if(isset($_POST["entry"])){
        $query = "select no_seats from trains where tid=".$_POST["t_id"];
        $result = mysqli_query($con,$query);
        if(!$result){
            echo mysqli_error($con);
            $exe = false;
        }
        if(mysqli_num_rows($result) == 0)
        {
            echo "The train ID is not available";
        }
        else{
            foreach($result as $row)
            $seats_available = $row['no_seats'];
            $seats_required = $_POST["t_seats"];
            if($seats_available<$seats_required){
                echo "The train doesn't have the required number of seats";
            }
            else{
                $query = "update trains set no_seats=no_seats-".$seats_required." where tid=".$_POST["t_id"];
                $result = mysqli_query($con,$query) or die("Couldn't update trains");
                $query = "insert into passengers values(".$_POST['p_id'].",'".$_POST['p_name']."','".$_POST['p_address']."',".$_POST['t_id'].",".$_POST['t_seats'].")";
                $result = mysqli_query($con,$query) or die("Couldn't update passengers"); 
                $target_dir = "c:xampp/htdocs/Lab12_XML/uploads/";

                $target_file = $target_dir.basename($_FILES["p_identity"]["name"]);
                //The basename() function returns the filename from a path.
                //_FILES - original name of file to be uploaded

                move_uploaded_file($_FILES["p_identity"]["tmp_name"], $target_file);
               
                echo "reservation successful";
            }
        }

    }
?>

<div><a href="RailwayReserver.php"> Back to Manager</a></div>