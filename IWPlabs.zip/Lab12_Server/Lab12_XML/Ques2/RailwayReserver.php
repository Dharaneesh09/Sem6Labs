<!DOCTYPE html>
<html lang="en">
<head>
    <title>Railway Reservation Manager</title>
    <style>
        *{
            font-size: 1.5rem;
        }
        table{
            width : 50%;
            margin : auto;
        }
        td{
            /* justify-content : center; */
            align-items : center;
        }
    </style>
</head>
<body>
    <h1>Railway Reservation Manager</h1>
    <table>
        <!-- Entering in to the database -->
        <form action="dataManager.php" method="post" enctype="multipart/form-data">
            <tr>    
                <th><h2>Enter Data</h2></th>
            </tr>
            <tr>
                <td>PID : </td>
                <td><input type="number" name="p_id" required/></td>
            </tr>
            <tr>
                <td>Name : </td>
                <td><input type="text" name="p_name" required/></td>
            </tr>
            <tr>
                <td>Address : </td>
                <td><input type="text" name="p_address" required/></td>
            </tr>
            <tr>
                <td>Train ID : </td>
                <td><input type="number" name="t_id" required/></td>
            </tr>
            <tr>
                <td>No of seats : </td>
                <td><input type="number" name="t_seats" required/></td>
            </tr>
            <tr>
                <td>Identity Proof : </td>
                <td><input type="file" name="p_identity" required/></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" name="entry" value="Enter Data"/></td>
            </tr>
        </form>

        
    </table>  
</body>
</html>