<?php

$xml = simplexml_load_file("data.xml");

echo "The No of drinks in the XML file : ".$xml->drink->children()->count();

?>