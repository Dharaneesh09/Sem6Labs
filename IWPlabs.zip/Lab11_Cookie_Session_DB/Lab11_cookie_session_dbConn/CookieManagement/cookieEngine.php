
<html lang="en">
<head>
    <title>Cookie Manager</title>
    <style>
        *{ 
            font-size: 2rem;
        }
    </style>
</head>
<body>
    <h2>
    <?php
        function SetmyCookie($color){
            setCookie("color",$color, time()+86400*3);
            echo "Setting Cookie successful";
        }
        function deleteCookie(){
            setCookie("color","", time()-3600);
            echo "Successfully deleted the Cookie";
        }

        function showCookie(){
            if(isset($_COOKIE["color"])){
                echo "Color : ".$_COOKIE['color'];
            }else{
                echo "Cookie unavailable";
            }

        }
        if(isset($_POST['setCookie'])){
            if(isset($_POST['colorInp'])){
                SetmyCookie($_POST['colorInp']);
            }else{
                echo "Please enter a color";
            }
        }
        if(isset($_POST['deleteCookie'])){
            deleteCookie();
        }
        if(isset($_POST['showCookie'])){
            showCookie();
        }

    ?>
    </h2>
    <?php
    echo "<a href='cookieManager.php'>back to Manager</a>";
    ?>
</body>
</html>
