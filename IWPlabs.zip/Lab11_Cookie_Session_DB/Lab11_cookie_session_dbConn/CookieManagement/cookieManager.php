<!DOCTYPE html>
<html lang="en">
<head>
    <title>Cookies</title>
    <style>
        *{ 
            font-size: 2rem;
        }
    </style>
</head>
<body>
    <h1>Playing with Cookies</h1>
    <form action="cookieEngine.php" method="post">
    <label for="colorInp">Color : </label>
    <input type="text" id="colorInp" name="colorInp">
    <input type="submit" name="setCookie" value="setCookie"><br><br>
    <input type="submit" name="deleteCookie" value="deleteCookie"><br><br>
    <input type="submit" name="showCookie" value="ShowCookie"><br><br>
    </form>
</body>
</html>