<?php
$cookie_name = "user";
$cookie_val = "Dharaneesh";
setcookie($cookie_name, $cookie_val, time()+86400*30, "/") // 86400 1 day

?>

<html>

<body>
    <h2>
        <?php
        if(!isset($_COOKIE[$cookie_name])){
            echo "Cookie named ".$cookie_name." is not set<br>";
        }else{
            echo "Cookie ".$cookie_name." is set<br>";
            echo "Value is ".$_COOKIE[$cookie_name]."<br>";
        }
        ?>
    </h2>
</body>

</html>