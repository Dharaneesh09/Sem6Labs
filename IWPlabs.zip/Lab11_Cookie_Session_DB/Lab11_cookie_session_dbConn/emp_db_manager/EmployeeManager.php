<!DOCTYPE html>
<html lang="en">
<head>
    <title>Employee Manager</title>
    <style>
        *{
            font-size: 1.5rem;
        }
        table{
            width : 50%;
            margin : auto;
        }
        td{
            /* justify-content : center; */
            align-items : center;
        }
    </style>
</head>
<body>
    <h1>Employee Manager</h1>
    <table>
        <!-- Entering in to the database -->
        <form action="dataManager.php" method="post">
            <tr>    
                <th><h2>Enter Data</h2></th>
            </tr>
            <tr>
                <td>ID : </td>
                <td><input type="number" name="e_id" required/></td>
            </tr>
            <tr>
                <td>Name : </td>
                <td><input type="text" name="e_name" required/></td>
            </tr>
            <tr>
                <td>Age : </td>
                <td><input type="number" name="e_age" required/></td>
            </tr>
            <tr>
                <td>Qualification : </td>
                <td><input type="text" name="e_qual" required/></td>
            </tr>
            <tr>
                <td>Designation : </td>
                <td><input type="text" name="e_des" required/></td>
            </tr>
            <tr>
                <td>Salary : </td>
                <td><input type="number" name="e_sal" min=0 max=999999999 required/></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" name="entry" value="Enter Data"/></td>
            </tr>
        </form>

        <!-- Updating the database -->
        <tr></tr>
        <tr></tr>
        <form action="dataManager.php" method="post">
            <tr>    
                <th><h2>Update Data</h2></th>
            </tr>
            <tr>
                <td>ID to be updated : </td>
                <td><input type="number" name="u_id" required/></td>
            </tr>
            <tr>
                <td>Name : </td>
                <td><input type="text" name="u_name"/></td>
            </tr>
            <tr>
                <td>Age : </td>
                <td><input type="number" name="u_age"/></td>
            </tr>
            <tr>
                <td>Qualification : </td>
                <td><input type="text" name="u_qual" /></td>
            </tr>
            <tr>
                <td>Designation : </td>
                <td><input type="text" name="u_des"/></td>
            </tr>
            <tr>
                <td>Salary : </td>
                <td><input type="number" name="u_sal" min=0 max=999999999/></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" name="update" value="Update Data"/></td>
            </tr>
        </form>

        <!-- Deleting from the database -->
        <tr></tr>
        <tr></tr>
        <form action="dataManager.php" method="post">
            <tr>    
                <th><h2>Delete Data</h2></th>
            </tr>
            <tr>
                <td>ID to be deleted : </td>
                <td><input type="number" name="d_id" required/></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" name="delete" value="Delete Data"/></td>
            </tr>
        </form>

        <th><form action="dataManager.php" method="post" ><input type="submit" name="dhpo" value="High Paid Ones"></form></th>
    </table>  
</body>
</html>