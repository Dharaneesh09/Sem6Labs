<?php

$con = mysqli_connect("localhost","root","") or die("Couldn't connect to Database");

$db = mysqli_query($con,"create database employee_db");

mysqli_query($con, "use employee_db");

$table = mysqli_query($con,"create table employee(id int, name varchar(30), age int, qualification varchar(30), designation varchar(30), salary int, constraint pk primary key(id))") or die("Couldn't create table employee");


?>