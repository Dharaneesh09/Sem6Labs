<?php 
    $con = mysqli_connect("localhost","root","","employee_db") or die("Couldn't connect to database");
    $query = "";
    if(isset($_POST["entry"])){
        $query = "insert into employee values(".$_POST['e_id'].",'".$_POST['e_name']."',".$_POST['e_age'].",'".$_POST['e_qual']."','".$_POST['e_des']."',".$_POST['e_sal'].")";
    }elseif(isset($_POST["update"])){
        $query = "update employee set ";
        $first = true;
        if($_POST["u_name"]!=""){
            $query .="name='".$_POST["u_name"]."' ";
            $first = false;
        }
        if($_POST["u_age"]!=""){
            if(! $first) $query .=",";
            $query .="age=".$_POST["u_age"]." ";
            $first = false;
        }
        if($_POST["u_qual"]!=""){
            if(! $first) $query .=",";
            $query .="qualification='".$_POST["u_qual"]."' ";
            $first = false;
        }
        if($_POST["u_des"]!=""){
            if(! $first) $query .=",";
            $query .="designation='".$_POST["u_des"]."' ";
            $first = false;
        }
        if($_POST["u_sal"]!=""){
            if(! $first) $query .=",";
            $query .="salary=".$_POST["u_sal"]." ";
            $first = false;
        }
        $query .="where id=".$_POST["u_id"];
    }elseif(isset($_POST["delete"])){
        $query = "delete from employee where id=".$_POST["d_id"];
    }
    $exe = false;
    if($query != ""){
        $q = mysqli_query($con, $query);
        $exe = true;
        if(!$q){
        echo mysqli_error($con);
        $exe = false;
        }
    }


    if(isset($_POST["dhpo"])){
        $result = mysqli_query($con,"select id,name,salary from employee where salary>(select avg(salary) from employee);");
        echo "<h2>Employee Having salary greater than average salary</h2><ol>";
        foreach($result as $row){
            echo "<li>".$row['name']."</li>";
        }
        echo "</ol>";
        $exe = true;
        if(!$result){
            echo mysqli_error($con);
            $exe = false;
        }
    }

    if($exe)
    echo "<h3>$query : Query Executed successfully</h3>";
?>

<div><a href="EmployeeManager.php"> Back to Manager</a></div>