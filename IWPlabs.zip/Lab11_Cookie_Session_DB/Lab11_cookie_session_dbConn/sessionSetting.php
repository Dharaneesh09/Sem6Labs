<?php
session_start();
?>

<html>
    <body>
        
    <?php
        $_SESSION["a"] = "Variable a";
        $_SESSION["b"] = "Variable b";
    ?>

</body>

</html>