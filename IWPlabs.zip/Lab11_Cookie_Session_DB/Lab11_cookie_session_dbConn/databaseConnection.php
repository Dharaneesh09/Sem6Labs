<?php

$con = mysqli_connect("localhost", "root", ""); // connecting with the server

if($con){
    echo "DB connected<br>";
}
else{
    echo "DB failed to connect<br>";
}

$db = mysqli_query($con,"create database db2");

$con = mysqli_connect("localhost", "root", "", "db2");

// mysqli_select_db($con, "myDB");

$tab = mysqli_query($con,"create table tk(eid int, ename varchar(20), age int)");

$data_in = mysqli_query($con, "load data infile 'C:/Users/ex1/Desktop/data.txt' into table tk fields terminated by ','");

mysqli_query($con,"insert into tk values (5,'Elon Musk',40)");
$result = mysqli_query($con,"select * from tk");
while($row = mysqli_fetch_array($result)){
    echo "EID -> ".$row["eid"]." Name -> ".$row["ename"]." Age -> ".$row["age"]."<br>";
}
?>