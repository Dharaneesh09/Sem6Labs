<!DOCTYPE html>
<html lang="en">
<head>
    <title>Retrieving</title>
</head>
<body>
    <h2>Retrieveing from the session:</h2>
    <?php session_start(); ?>
    a - <?php echo $_SESSION["a"]; ?><br>
    b - <?php echo $_SESSION["b"]; ?><br>
</body>
</html>